@API(apiVersion = "1.0", owner = "miragecrops6", provides = "MirageCrops6API")
package miragecrops6.api;

import cpw.mods.fml.common.API;

