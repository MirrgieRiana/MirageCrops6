package miragecrops6.ali;

public interface IAliEntry<T>
{

	public String name();

	public T getValue();

}
