package miragecrops6.alis;

import mirrg.minecraft.item.multi.copper.ItemMulti;

public class AliItem
{

	public static ItemMulti multiCrops;

}
