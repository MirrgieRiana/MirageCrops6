package miragecrops6.alis;

import net.minecraft.item.ItemStack;

public class AliItemStack
{

	public static ItemStack

		// 000
		cropSpinach,
		cropSpinachRed,
		cropSpinachBlue,
		cropSpinachPoison,
		cropSpinachFire,
		cropSpinachIce,

		// 100
		cropSarracenia,
		cropSarraceniaImmature,
		cropSarraceniaLightning,
		cropSarraceniaNagae,
		cropSarraceniaManeater,
		cropSarraceniaDevil,

		// 200
		cropRose,
		cropRoseQuartz,
		gemCertusQuartz,

		// 300
		cropReedCircuit,
		cropReedWire,
		cropWartGlass,
		dustGlass,

		// 400
		cropCactus,
		cropCactusObsidian,
		cropCactusSnow,

		// 500
		gemApatite,
		cropVineFluoroberries,

		// 600
		cropMandrake,
		gemSulfur;

}
