package miragecrops6.alis;

import miragecrops6.crop.CropCardMirageCrops;

public class AliCrop
{

	public static CropCardMirageCrops
		wheatFire,
		rice,
		coffeeJava,
		mandrake,
		dreamflower,

		roseQuartz,
		chrysanthum,
		chrysanthumErodium,
		chrysanthumIridium,

		reedCircuit,
		berriesMatter,
		wartGlass,
		wartMatter,

		cactus,
		cactusObsidian,
		cactusSnow,

		spinach,
		spinachRed,
		spinachBlue,
		spinachPoison,
		spinachFire,
		spinachIce,

		fern,
		fernHoney,
		vine,
		vineApatite,
		vineFluoroberries,

		sarracenia,
		sarraceniaLightning,
		sarraceniaManeater,
		sarraceniaNagae,
		sarraceniaDevil;

}
